const projects = [
  {id:1,title:"Student Portfolio Website",category:"html",technology:"HTML, CSS, JavaScript",description:"A responsive personal portfolio that presents student details, education, skills, achievements and projects. Includes project filters and a validated contact form.",symbol:"SP",link:"https://github.com/"},
  {id:2,title:"Task Planner",category:"javascript",technology:"HTML, CSS, JavaScript",description:"A simple task-planning interface concept. This sample can be extended with task creation, completion status and browser storage.",symbol:"✓",link:"https://github.com/"},
  {id:3,title:"Campus Landing Page",category:"design",technology:"HTML, CSS",description:"A clean landing-page design for a campus event, with responsive sections and clear calls to action.",symbol:"UI",link:"https://github.com/"},
  {id:4,title:"Quiz Application",category:"javascript",technology:"HTML, CSS, JavaScript",description:"An interactive quiz concept that can show questions, accept answers and display a score.",symbol:"Q?",link:"https://github.com/"},
  {id:5,title:"Learning Resources Page",category:"html",technology:"HTML, CSS",description:"A structured page for sharing learning links and resources in a readable, mobile-friendly layout.",symbol:"</>",link:"https://github.com/"},
  {id:6,title:"Mobile App Wireframe",category:"design",technology:"UI Design",description:"A sample wireframe concept focusing on navigation clarity, readable text and consistent spacing.",symbol:"✧",link:"https://github.com/"}
];
const grid = document.getElementById("projectsGrid");
const filters = document.querySelectorAll(".filter-btn");
const dialog = document.getElementById("projectDialog");

function renderProjects(filter = "all") {
  const shown = projects.filter(p => filter === "all" || p.category === filter);
  grid.innerHTML = shown.map(p => `
    <article class="project-card">
      <div class="project-art" aria-hidden="true">${p.symbol}</div>
      <div class="project-body">
        <span class="tag">${p.category.toUpperCase()}</span>
        <h3>${p.title}</h3>
        <p>${p.description}</p>
        <div class="project-actions">
          <button class="text-button details-btn" data-id="${p.id}">View details ↗</button>
          <a class="text-button" href="${p.link}" target="_blank" rel="noreferrer">Project link ↗</a>
        </div>
      </div>
    </article>`).join("");
}
filters.forEach(button => button.addEventListener("click", () => {
  filters.forEach(b => b.classList.remove("active"));
  button.classList.add("active");
  renderProjects(button.dataset.filter);
}));
grid.addEventListener("click", event => {
  const button = event.target.closest(".details-btn");
  if (!button) return;
  const project = projects.find(p => p.id === Number(button.dataset.id));
  if (!project) return;
  document.getElementById("dialogTitle").textContent = project.title;
  document.getElementById("dialogDescription").textContent = project.description;
  document.getElementById("dialogTech").textContent = project.technology;
  const link = document.getElementById("dialogLink");
  link.href = project.link;
  dialog.showModal();
});
document.getElementById("dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => { if (event.target === dialog) dialog.close(); });

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
});
navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

document.getElementById("contactForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.getElementById("formMessage");
  message.className = "form-message";
  if (!form.checkValidity()) {
    message.textContent = "Please complete every required field correctly. The message must be at least 10 characters.";
    message.classList.add("error");
    form.reportValidity();
    return;
  }
  message.textContent = "Validation successful! This demo does not send the message to a server.";
  message.classList.add("success");
  form.reset();
});
document.getElementById("year").textContent = new Date().getFullYear();
renderProjects();
